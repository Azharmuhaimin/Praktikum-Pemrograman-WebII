<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

<style>

body {
        background-image: url("../images/Background.png");
        background-repeat: no-repeat;
        background-size: cover;
    }

.jumbotron {
    font-size: 16px;
    padding: 25px;
    background-color: #ff8c00;
    text-align: center;
    color: white;
 }

 .card {
    margin: auto;
    width: 100% ;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    padding: 20px;
    margin-top: 20px;
 }

</style>
</head>
<body>
    <div class="container">
        <div class="pt-5 d-flex justify-content-between jumbotron">
            <div class="col">
                <h1>Selamat Datang di Perpustakaan</h1>
                <p>Ini adalah halaman home</p>
            </div>
            <div class="mt-3">
                <a href="<?= base_url('/logout') ?>" class="btn btn-light">Logout</a>
            </div>
        </div>

        <!-- create list of books -->
        <div class="row card">
            <div class="col-12">
                <h2>Daftar Buku</h2>
                <a class="btn btn-success" href="<?= base_url('/tambah')?>">Tambah Data</a>
            </div>

            <div class="col-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Judul</th>
                            <th>Penulis</th>
                            <th>Penerbit</th>
                            <th>Tahun Terbit</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($data as $baris):?>
                            <tr>
                                <td><?= $baris['judul'] ?></td>
                                <td><?= $baris['penulis'] ?></td>
                                <td><?= $baris['penerbit'] ?></td>
                                <td><?= $baris['tahun_terbit'] ?></td>
                                <td>
                                    <a href="<?= base_url('/editdata/'.$baris['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <!-- <a href="" class="btn btn-sm btn-danger">Hapus</a> -->
                                    <form action="<?= base_url('/hapusdata/'.$baris['id']) ?>" method="post" style="display: inline-block">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('apakah anda yakin ingin menghapus datanya?')">hapus</button>
                                    </form>
                                </td>
                            </tr>
                           <?php endforeach ?>
                        
                    </tbody>
                </table>
            </div>
                
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>