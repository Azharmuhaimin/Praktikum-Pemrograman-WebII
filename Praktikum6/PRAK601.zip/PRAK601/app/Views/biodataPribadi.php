<!DOCTYPE html>
<html>

<head>
    <title>Biodata </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>

body {
    background-image: url("../images/background.png");
    background-repeat: no-repeat;
    background-size: cover;
     }

.card {
    margin: auto;
    width: 40% ;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    padding: 20px;
    margin-top: 5px;
 }

h1 {
        text-align: center;
        margin-bottom: 15px;
    }

img {
    width: 150px;
    height: 200px;
    }

    </style>
</head>

<body>
    <br><br>
    <div class="card">
        <h1>Biodata</h1>

        <center><img src="<?= base_url('images/' . $foto) ?>"></center>
        <center><table>
            <tr>
                </td>
                <th>Nama Lengkap : </th>
                <td>
                    <?= $nama; ?>
                </td>
            </tr>
            <tr>
                <th>NIM : </th>
                <td>
                    <?= $nim; ?>
                </td>
            </tr>
            <tr>
                <th>Asal Prodi : </th>
                <td>
                    <?= $prodi; ?>
                </td>
            </tr>
                <th>Hobi : </th>
                <td>
                    <?= $hobi; ?>
                </td>
            </tr>
            <tr>
                <th>Skill : </th>
                <td>
                    <?= $skill; ?>
                </td>
        </table> </center>
    </div>
    <div class="mt-2">
        <form action="/home/index">
            <center><button>Menu Awal</button></center>
    </div>
    </form>

</body>

</html>