<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "M. Azhar Muhaimin";
    protected $nim = "2110817310019";
    protected $prodi = "Teknologi Informasi";
    protected $hobi = "Nonton Bola, Membaca Komik";
    protected $skill = "Bermain Game";
    protected $foto = "IMG.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getHobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}